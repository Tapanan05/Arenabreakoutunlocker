# Put sepolicy statements here
# Example: allow { audioserver mediaserver } audioserver_tmpfs file { read write open }
